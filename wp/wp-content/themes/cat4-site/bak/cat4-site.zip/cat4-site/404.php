<?php get_header(); ?>

	<div id="content">
		<h2>Error 404: Not Found</h2>
		<p>Please check the URL you are using, to see if it's correct. If the URL is correct, it is possible that the item you are looking for has moved or no longer exists on this site. <a href="/">Back to the homepage?</a></p>
	</div>

<?php get_sidebar(); ?>
  
<?php get_footer(); ?>