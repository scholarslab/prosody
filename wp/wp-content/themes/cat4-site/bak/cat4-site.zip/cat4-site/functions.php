<?php

$themename = "Cat4 Baseline Theme";
$shortname = "Cat4 Baseline Theme";

if ( function_exists('register_sidebar') )
    register_sidebar(array(
        'before_widget' => '<div class="widget">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>',
    ));
?>